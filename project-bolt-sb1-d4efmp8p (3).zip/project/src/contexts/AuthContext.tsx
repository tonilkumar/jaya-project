import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { User, Patient, Doctor, AuthContextType } from '../types';
import toast from 'react-hot-toast';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [patient, setPatient] = useState<Patient | null>(null);
  const [doctor, setDoctor] = useState<Doctor | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const initializeAuth = async () => {
      try {
        console.log('Initializing auth...');
        
        // Get initial session
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError) {
          console.error('Session error:', sessionError);
          if (mounted) setLoading(false);
          return;
        }

        if (session?.user && mounted) {
          console.log('Found session, fetching profile...');
          await fetchUserProfile(session.user.id);
        } else {
          console.log('No session found');
          if (mounted) setLoading(false);
        }
      } catch (error) {
        console.error('Auth initialization error:', error);
        if (mounted) setLoading(false);
      }
    };

    initializeAuth();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log('Auth state changed:', event);
        
        if (session?.user && mounted) {
          await fetchUserProfile(session.user.id);
        } else if (mounted) {
          setUser(null);
          setPatient(null);
          setDoctor(null);
          setLoading(false);
        }
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const fetchUserProfile = async (userId: string) => {
    try {
      console.log('Fetching profile for user:', userId);

      // Get auth user for email
      const { data: authUser, error: authError } = await supabase.auth.getUser();
      if (authError || !authUser.user) {
        console.error('Auth user error:', authError);
        setLoading(false);
        return;
      }

      // Try to get user role - if it fails, default to patient
      let userRole = 'patient';
      try {
        const { data: roleData, error: roleError } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', userId)
          .single();

        if (!roleError && roleData) {
          userRole = roleData.role;
        }
      } catch (roleError) {
        console.log('No role found, defaulting to patient');
      }

      const userData: User = {
        id: userId,
        email: authUser.user.email!,
        role: userRole as any,
        created_at: authUser.user.created_at
      };
      
      setUser(userData);
      console.log('User set:', userData);

      // Try to fetch profile data - don't block on errors
      if (userRole === 'patient') {
        try {
          const { data: profileData } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', userId)
            .single();
          
          if (profileData) {
            setPatient(profileData);
            console.log('Patient profile loaded');
          }
        } catch (error) {
          console.log('No patient profile found');
        }
      } else if (userRole === 'doctor') {
        try {
          const { data: doctorData } = await supabase
            .from('doctors')
            .select('*')
            .eq('user_id', userId)
            .single();
          
          if (doctorData) {
            setDoctor(doctorData);
            console.log('Doctor profile loaded');
          }
        } catch (error) {
          console.log('No doctor profile found');
        }
      }

    } catch (error) {
      console.error('Error fetching user profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      throw error;
    }
  };

  const signUp = async (email: string, password: string, role: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) {
      throw error;
    }

    // Create user role entry if user was created
    if (data.user) {
      try {
        const { error: roleError } = await supabase
          .from('user_roles')
          .insert({
            user_id: data.user.id,
            role: role as any
          });

        if (roleError) {
          console.error('Error creating user role:', roleError);
        }
      } catch (error) {
        console.error('Role creation failed:', error);
      }
    }
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast.error('Error signing out');
    }
  };

  const value = {
    user,
    patient,
    doctor,
    loading,
    signIn,
    signUp,
    signOut,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}