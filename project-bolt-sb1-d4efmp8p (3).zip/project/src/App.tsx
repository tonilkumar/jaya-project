import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LandingPage } from './components/LandingPage';
import { Layout } from './components/Layout';
import { AuthPage } from './components/auth/AuthPage';
import { PatientDashboard } from './components/dashboard/PatientDashboard';
import { DoctorDashboard } from './components/dashboard/DoctorDashboard';
import { AdminDashboard } from './components/dashboard/AdminDashboard';
import { BookAppointment } from './components/appointments/BookAppointment';
import { AppointmentsList } from './components/appointments/AppointmentsList';
import { PatientProfile } from './components/profile/PatientProfile';
import { DoctorProfile } from './components/profile/DoctorProfile';
import { DoctorAvailability } from './components/doctor/DoctorAvailability';
import { DoctorAppointments } from './components/doctor/DoctorAppointments';
import { AdminDoctors } from './components/admin/AdminDoctors';
import { AdminAppointments } from './components/admin/AdminAppointments';
import { AdminPatients } from './components/admin/AdminPatients';

function AppRoutes() {
  const { user, loading } = useAuth();

  console.log('AppRoutes render - loading:', loading, 'user:', user);

  if (loading) {
    console.log('Showing loading spinner');
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    console.log('No user, showing public routes');
    return (
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/auth" element={<AuthPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    );
  }

  console.log('User found, showing authenticated routes');
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route 
          path="/dashboard" 
          element={
            user.role === 'patient' ? <PatientDashboard /> :
            user.role === 'doctor' ? <DoctorDashboard /> :
            user.role === 'admin' ? <AdminDashboard /> :
            <Navigate to="/" replace />
          } 
        />
        
        {/* Patient Routes */}
        {user.role === 'patient' && (
          <>
            <Route path="/book-appointment" element={<BookAppointment />} />
            <Route path="/appointments" element={<AppointmentsList />} />
            <Route path="/profile" element={<PatientProfile />} />
          </>
        )}
        
        {/* Doctor Routes */}
        {user.role === 'doctor' && (
          <>
            <Route path="/doctor/appointments" element={<DoctorAppointments />} />
            <Route path="/doctor/availability" element={<DoctorAvailability />} />
            <Route path="/doctor/profile" element={<DoctorProfile />} />
          </>
        )}
        
        {/* Admin Routes */}
        {user.role === 'admin' && (
          <>
            <Route path="/admin/doctors" element={<AdminDoctors />} />
            <Route path="/admin/appointments" element={<AdminAppointments />} />
            <Route path="/admin/patients" element={<AdminPatients />} />
          </>
        )}
        
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Layout>
  );
}

function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
        <Toaster 
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#363636',
              color: '#fff',
            },
          }}
        />
      </Router>
    </AuthProvider>
  );
}

export default App;