import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Guitar as Hospital, User, Calendar, Settings, LogOut } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { user, patient, doctor, signOut } = useAuth();
  const location = useLocation();

  const getNavItems = () => {
    if (!user) return [];

    const baseItems = [
      { path: '/dashboard', label: 'Dashboard', icon: Calendar },
    ];

    if (user.role === 'patient') {
      return [
        ...baseItems,
        { path: '/appointments', label: 'My Appointments', icon: Calendar },
        { path: '/book-appointment', label: 'Book Appointment', icon: Calendar },
        { path: '/profile', label: 'Profile', icon: User },
      ];
    }

    if (user.role === 'doctor') {
      return [
        ...baseItems,
        { path: '/doctor/appointments', label: 'Appointments', icon: Calendar },
        { path: '/doctor/availability', label: 'Availability', icon: Settings },
        { path: '/doctor/profile', label: 'Profile', icon: User },
      ];
    }

    if (user.role === 'admin') {
      return [
        ...baseItems,
        { path: '/admin/doctors', label: 'Manage Doctors', icon: User },
        { path: '/admin/appointments', label: 'All Appointments', icon: Calendar },
        { path: '/admin/patients', label: 'Patients', icon: User },
      ];
    }

    return baseItems;
  };

  const navItems = getNavItems();

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
        {children}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <Hospital className="w-8 h-8 text-blue-600" />
              <h1 className="text-xl font-bold text-gray-900">MediCare Hospital</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-sm text-gray-600">
                Welcome, {patient?.full_name || user.email}
              </div>
              <button
                onClick={signOut}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <nav className="w-64 bg-white shadow-sm min-h-screen border-r border-gray-200">
          <div className="p-4">
            <div className="space-y-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${
                      isActive
                        ? 'bg-blue-50 text-blue-700 border border-blue-200'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {children}
        </main>
      </div>
    </div>
  );
}