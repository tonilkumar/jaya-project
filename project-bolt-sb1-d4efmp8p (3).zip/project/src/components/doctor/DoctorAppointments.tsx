import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';
import { Appointment, Patient } from '../../types';
import { Calendar, Clock, User, Phone, MapPin, Video, FileText, CheckCircle, XCircle } from 'lucide-react';
import { format, parseISO, isToday, isTomorrow, startOfDay, endOfDay } from 'date-fns';
import toast from 'react-hot-toast';

export function DoctorAppointments() {
  const { doctor } = useAuth();
  const [appointments, setAppointments] = useState<(Appointment & { patient: Patient })[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'today' | 'upcoming' | 'past' | 'all'>('today');
  const [selectedAppointment, setSelectedAppointment] = useState<string | null>(null);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (doctor) {
      fetchAppointments();
    }
  }, [doctor, filter]);

  const fetchAppointments = async () => {
    if (!doctor) return;

    try {
      let query = supabase
        .from('appointments')
        .select(`
          *,
          patient:patients(*)
        `)
        .eq('doctor_id', doctor.id);

      const today = new Date();
      const todayStr = format(today, 'yyyy-MM-dd');

      switch (filter) {
        case 'today':
          query = query.eq('appointment_date', todayStr);
          break;
        case 'upcoming':
          query = query
            .gte('appointment_date', todayStr)
            .eq('status', 'scheduled');
          break;
        case 'past':
          query = query.lt('appointment_date', todayStr);
          break;
        default:
          // all appointments
          break;
      }

      const { data, error } = await query
        .order('appointment_date', { ascending: true })
        .order('appointment_time', { ascending: true });

      if (error) throw error;
      setAppointments(data || []);
    } catch (error) {
      console.error('Error fetching appointments:', error);
      toast.error('Failed to load appointments');
    } finally {
      setLoading(false);
    }
  };

  const updateAppointmentStatus = async (appointmentId: string, status: 'completed' | 'cancelled', consultationNotes?: string) => {
    try {
      const updateData: any = { status };
      if (consultationNotes) {
        updateData.notes = consultationNotes;
      }

      const { error } = await supabase
        .from('appointments')
        .update(updateData)
        .eq('id', appointmentId);

      if (error) throw error;

      toast.success(`Appointment ${status} successfully`);
      fetchAppointments();
      setSelectedAppointment(null);
      setNotes('');
    } catch (error: any) {
      toast.error(error.message || `Failed to ${status} appointment`);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'scheduled':
        return 'bg-blue-100 text-blue-800';
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      case 'rescheduled':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getDateLabel = (dateString: string) => {
    const date = parseISO(dateString);
    if (isToday(date)) return 'Today';
    if (isTomorrow(date)) return 'Tomorrow';
    return format(date, 'MMM dd, yyyy');
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">My Appointments</h1>
          
          {/* Filter Tabs */}
          <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
            {[
              { key: 'today', label: 'Today' },
              { key: 'upcoming', label: 'Upcoming' },
              { key: 'past', label: 'Past' },
              { key: 'all', label: 'All' },
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setFilter(tab.key as any)}
                className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${
                  filter === tab.key
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-32 bg-gray-200 rounded-lg"></div>
              </div>
            ))}
          </div>
        ) : appointments.length > 0 ? (
          <div className="space-y-4">
            {appointments.map((appointment) => (
              <div
                key={appointment.id}
                className="border border-gray-200 rounded-lg p-6 hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4 flex-1">
                    <div className="bg-blue-100 p-3 rounded-lg">
                      <User className="w-6 h-6 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="font-semibold text-gray-900">
                          {appointment.patient.name}
                        </h3>
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(appointment.status)}`}>
                          {appointment.status}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <Calendar className="w-4 h-4" />
                            <span>{getDateLabel(appointment.appointment_date)}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Clock className="w-4 h-4" />
                            <span>{appointment.appointment_time}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            {appointment.consultation_type === 'video' ? (
                              <>
                                <Video className="w-4 h-4" />
                                <span>Video Consultation</span>
                              </>
                            ) : (
                              <>
                                <MapPin className="w-4 h-4" />
                                <span>In-Person Visit</span>
                              </>
                            )}
                          </div>
                        </div>
                        
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <Phone className="w-4 h-4" />
                            <span>{appointment.patient.phone}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <User className="w-4 h-4" />
                            <span>{appointment.patient.age}y, {appointment.patient.gender}</span>
                          </div>
                          <div className="text-green-600 font-medium">
                            Fee: ₹{appointment.consultation_fee}
                          </div>
                        </div>
                      </div>

                      {appointment.patient.medical_history && (
                        <div className="mt-3 p-3 bg-yellow-50 rounded-lg">
                          <p className="text-sm text-yellow-800">
                            <strong>Medical History:</strong> {appointment.patient.medical_history}
                          </p>
                        </div>
                      )}

                      {appointment.notes && (
                        <div className="mt-3 p-3 bg-green-50 rounded-lg">
                          <p className="text-sm text-green-800">
                            <strong>Consultation Notes:</strong> {appointment.notes}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  {appointment.status === 'scheduled' && (
                    <div className="flex flex-col space-y-2 ml-4">
                      <button
                        onClick={() => setSelectedAppointment(appointment.id)}
                        className="flex items-center space-x-1 px-3 py-1 text-sm text-green-600 bg-green-50 rounded-lg hover:bg-green-100 transition-colors"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>Complete</span>
                      </button>
                      <button
                        onClick={() => updateAppointmentStatus(appointment.id, 'cancelled')}
                        className="flex items-center space-x-1 px-3 py-1 text-sm text-red-600 bg-red-50 rounded-lg hover:bg-red-100 transition-colors"
                      >
                        <XCircle className="w-4 h-4" />
                        <span>Cancel</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Notes Modal */}
                {selectedAppointment === appointment.id && (
                  <div className="mt-4 p-4 border-t border-gray-200">
                    <h4 className="font-medium text-gray-900 mb-3">Add Consultation Notes</h4>
                    <textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Enter consultation notes, diagnosis, prescriptions, etc."
                    />
                    <div className="flex space-x-3 mt-3">
                      <button
                        onClick={() => updateAppointmentStatus(appointment.id, 'completed', notes)}
                        className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>Complete Appointment</span>
                      </button>
                      <button
                        onClick={() => {
                          setSelectedAppointment(null);
                          setNotes('');
                        }}
                        className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {filter === 'today' ? 'No Appointments Today' : 
               filter === 'upcoming' ? 'No Upcoming Appointments' :
               filter === 'past' ? 'No Past Appointments' : 'No Appointments'}
            </h3>
            <p className="text-gray-600">
              {filter === 'today' ? 'Your schedule is clear for today.' : 
               'Appointments will appear here once patients book them.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}