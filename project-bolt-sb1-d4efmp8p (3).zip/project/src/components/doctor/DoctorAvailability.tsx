import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';
import { Clock, Calendar, Save, Plus, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';

interface AvailabilitySlot {
  id?: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
  is_available: boolean;
}

const DAYS_OF_WEEK = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
];

export function DoctorAvailability() {
  const { doctor } = useAuth();
  const [availability, setAvailability] = useState<AvailabilitySlot[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (doctor) {
      fetchAvailability();
    }
  }, [doctor]);

  const fetchAvailability = async () => {
    if (!doctor) return;

    try {
      const { data, error } = await supabase
        .from('doctor_availability')
        .select('*')
        .eq('doctor_id', doctor.id)
        .order('day_of_week');

      if (error) throw error;

      // Initialize with default availability if none exists
      if (!data || data.length === 0) {
        const defaultAvailability: AvailabilitySlot[] = [];
        for (let day = 1; day <= 5; day++) { // Monday to Friday
          defaultAvailability.push({
            day_of_week: day,
            start_time: '09:00',
            end_time: '17:00',
            is_available: true,
          });
        }
        setAvailability(defaultAvailability);
      } else {
        setAvailability(data);
      }
    } catch (error) {
      console.error('Error fetching availability:', error);
      toast.error('Failed to load availability');
    } finally {
      setLoading(false);
    }
  };

  const addTimeSlot = (dayOfWeek: number) => {
    const newSlot: AvailabilitySlot = {
      day_of_week: dayOfWeek,
      start_time: '09:00',
      end_time: '17:00',
      is_available: true,
    };
    setAvailability([...availability, newSlot]);
  };

  const removeTimeSlot = (index: number) => {
    setAvailability(availability.filter((_, i) => i !== index));
  };

  const updateTimeSlot = (index: number, field: keyof AvailabilitySlot, value: any) => {
    const updated = [...availability];
    updated[index] = { ...updated[index], [field]: value };
    setAvailability(updated);
  };

  const saveAvailability = async () => {
    if (!doctor) return;

    setSaving(true);
    try {
      // Delete existing availability
      await supabase
        .from('doctor_availability')
        .delete()
        .eq('doctor_id', doctor.id);

      // Insert new availability
      const availabilityData = availability.map(slot => ({
        doctor_id: doctor.id,
        day_of_week: slot.day_of_week,
        start_time: slot.start_time,
        end_time: slot.end_time,
        is_available: slot.is_available,
      }));

      const { error } = await supabase
        .from('doctor_availability')
        .insert(availabilityData);

      if (error) throw error;

      toast.success('Availability updated successfully!');
      fetchAvailability();
    } catch (error: any) {
      toast.error(error.message || 'Failed to save availability');
    } finally {
      setSaving(false);
    }
  };

  const getAvailabilityForDay = (dayOfWeek: number) => {
    return availability.filter(slot => slot.day_of_week === dayOfWeek);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Manage Availability</h1>
            <p className="text-gray-600 mt-1">Set your working hours and availability for appointments</p>
          </div>
          <button
            onClick={saveAvailability}
            disabled={saving}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Saving...' : 'Save Changes'}</span>
          </button>
        </div>

        <div className="space-y-6">
          {DAYS_OF_WEEK.map((dayName, dayIndex) => {
            const daySlots = getAvailabilityForDay(dayIndex);
            
            return (
              <div key={dayIndex} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium text-gray-900">{dayName}</h3>
                  <button
                    onClick={() => addTimeSlot(dayIndex)}
                    className="flex items-center space-x-1 text-sm text-blue-600 hover:text-blue-700 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Time Slot</span>
                  </button>
                </div>

                {daySlots.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Calendar className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                    <p>No availability set for this day</p>
                    <button
                      onClick={() => addTimeSlot(dayIndex)}
                      className="mt-2 text-sm text-blue-600 hover:text-blue-700"
                    >
                      Add your first time slot
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {daySlots.map((slot, slotIndex) => {
                      const globalIndex = availability.findIndex(
                        s => s.day_of_week === dayIndex && 
                        s.start_time === slot.start_time && 
                        s.end_time === slot.end_time
                      );
                      
                      return (
                        <div key={slotIndex} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                              checked={slot.is_available}
                              onChange={(e) => updateTimeSlot(globalIndex, 'is_available', e.target.checked)}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            />
                            <span className="text-sm font-medium text-gray-700">Available</span>
                          </div>

                          <div className="flex items-center space-x-2">
                            <Clock className="w-4 h-4 text-gray-400" />
                            <input
                              type="time"
                              value={slot.start_time}
                              onChange={(e) => updateTimeSlot(globalIndex, 'start_time', e.target.value)}
                              className="px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                            <span className="text-gray-500">to</span>
                            <input
                              type="time"
                              value={slot.end_time}
                              onChange={(e) => updateTimeSlot(globalIndex, 'end_time', e.target.value)}
                              className="px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                          </div>

                          <button
                            onClick={() => removeTimeSlot(globalIndex)}
                            className="text-red-600 hover:text-red-700 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-medium text-blue-900 mb-2">Tips for Setting Availability:</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Set realistic time slots with breaks between appointments</li>
            <li>• Consider 30-minute slots for regular consultations</li>
            <li>• Leave buffer time for emergency cases</li>
            <li>• Update your availability regularly for holidays and leaves</li>
          </ul>
        </div>
      </div>
    </div>
  );
}