import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';
import { Doctor, Department, TimeSlot } from '../../types';
import { Calendar, Clock, User, CreditCard, Video, MapPin } from 'lucide-react';
import { format, addDays, parseISO } from 'date-fns';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';

const bookingSchema = z.object({
  department: z.string().min(1, 'Please select a department'),
  doctorId: z.string().min(1, 'Please select a doctor'),
  appointmentDate: z.string().min(1, 'Please select a date'),
  appointmentTime: z.string().min(1, 'Please select a time'),
  consultationType: z.enum(['in-person', 'video']),
});

type BookingFormData = z.infer<typeof bookingSchema>;

export function BookAppointment() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [departments] = useState<Department[]>([
    { id: '1', name: 'Cardiology', description: 'Heart and cardiovascular care', icon: '❤️' },
    { id: '2', name: 'Orthopedics', description: 'Bone and joint care', icon: '🦴' },
    { id: '3', name: 'General Medicine', description: 'Primary healthcare', icon: '🩺' },
    { id: '4', name: 'Pediatrics', description: 'Child healthcare', icon: '👶' },
    { id: '5', name: 'Dermatology', description: 'Skin care', icon: '🧴' },
    { id: '6', name: 'Neurology', description: 'Brain and nervous system', icon: '🧠' },
  ]);
  
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [availableSlots, setAvailableSlots] = useState<TimeSlot[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<BookingFormData>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      consultationType: 'in-person',
    },
  });

  const selectedDepartment = watch('department');
  const selectedDate = watch('appointmentDate');
  const selectedDoctorId = watch('doctorId');

  useEffect(() => {
    if (selectedDepartment) {
      fetchDoctorsByDepartment(selectedDepartment);
    }
  }, [selectedDepartment]);

  useEffect(() => {
    if (selectedDoctorId) {
      const doctor = doctors.find(d => d.id === selectedDoctorId);
      setSelectedDoctor(doctor || null);
    }
  }, [selectedDoctorId, doctors]);

  useEffect(() => {
    if (selectedDoctor && selectedDate) {
      fetchAvailableSlots(selectedDoctor.id, selectedDate);
    }
  }, [selectedDoctor, selectedDate]);

  const fetchDoctorsByDepartment = async (department: string) => {
    try {
      // First get the department ID
      const { data: deptData, error: deptError } = await supabase
        .from('departments')
        .select('id')
        .eq('name', department)
        .single();

      if (deptError) throw deptError;

      const { data, error } = await supabase
        .from('doctors')
        .select(`
          *,
          department:departments(name)
        `)
        .eq('department_id', deptData.id)
        .eq('is_available', true);

      if (error) throw error;
      setDoctors(data || []);
      setValue('doctorId', '');
      setSelectedDoctor(null);
    } catch (error) {
      console.error('Error fetching doctors:', error);
      toast.error('Failed to load doctors');
    }
  };

  const fetchAvailableSlots = async (doctorId: string, date: string) => {
    try {
      // Get existing appointments for the selected date
      const { data: existingAppointments, error } = await supabase
        .from('appointments')
        .select('appointment_time')
        .eq('doctor_id', doctorId)
        .eq('appointment_date', date)
        .eq('status', 'scheduled');

      if (error) throw error;

      const bookedTimes = existingAppointments?.map(apt => apt.appointment_time) || [];
      
      // Generate time slots (9 AM to 5 PM, 30-minute intervals)
      const slots: TimeSlot[] = [];
      for (let hour = 9; hour < 17; hour++) {
        for (let minute = 0; minute < 60; minute += 30) {
          const time = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
          slots.push({
            time,
            available: !bookedTimes.includes(time),
          });
        }
      }

      setAvailableSlots(slots);
    } catch (error) {
      console.error('Error fetching available slots:', error);
      toast.error('Failed to load available time slots');
    }
  };

  const onSubmit = async (data: BookingFormData) => {
    if (!user || !selectedDoctor) {
      toast.error('Please complete your profile first');
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('appointments')
        .insert({
          patient_id: user.id,
          doctor_id: data.doctorId,
          appointment_date: data.appointmentDate,
          appointment_time: data.appointmentTime,
          consultation_type: data.consultationType,
          consultation_fee: selectedDoctor.consultation_fee,
          status: 'scheduled',
          payment_status: 'pending',
        });

      if (error) throw error;

      toast.success('Appointment booked successfully!');
      navigate('/appointments');
    } catch (error: any) {
      toast.error(error.message || 'Failed to book appointment');
    } finally {
      setIsLoading(false);
    }
  };

  // Generate next 14 days for date selection
  const availableDates = Array.from({ length: 14 }, (_, i) => {
    const date = addDays(new Date(), i);
    return {
      value: format(date, 'yyyy-MM-dd'),
      label: format(date, 'EEE, MMM dd'),
      isToday: i === 0,
    };
  });

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Book an Appointment</h1>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Department Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Select Department
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {departments.map((dept) => (
                <label key={dept.id} className="relative">
                  <input
                    {...register('department')}
                    type="radio"
                    value={dept.name}
                    className="sr-only"
                  />
                  <div className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    selectedDepartment === dept.name
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-300 hover:border-gray-400'
                  }`}>
                    <div className="text-center">
                      <div className="text-2xl mb-2">{dept.icon}</div>
                      <h3 className="font-medium text-gray-900">{dept.name}</h3>
                      <p className="text-xs text-gray-600 mt-1">{dept.description}</p>
                    </div>
                  </div>
                </label>
              ))}
            </div>
            {errors.department && (
              <p className="mt-2 text-sm text-red-600">{errors.department.message}</p>
            )}
          </div>

          {/* Doctor Selection */}
          {selectedDepartment && doctors.length > 0 && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Select Doctor
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {doctors.map((doctor) => (
                  <label key={doctor.id} className="relative">
                    <input
                      {...register('doctorId')}
                      type="radio"
                      value={doctor.id}
                      className="sr-only"
                    />
                    <div className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                      selectedDoctorId === doctor.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}>
                      <div className="flex items-start space-x-3">
                        <div className="bg-gray-200 w-12 h-12 rounded-full flex items-center justify-center">
                          <User className="w-6 h-6 text-gray-600" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium text-gray-900">Dr. {doctor.name}</h3>
                          <p className="text-sm text-gray-600">{doctor.specialization}</p>
                          <p className="text-sm text-gray-600">{doctor.experience_years} years exp.</p>
                          <p className="text-sm font-medium text-green-600 mt-1">₹{doctor.consultation_fee}</p>
                        </div>
                      </div>
                    </div>
                  </label>
                ))}
              </div>
              {errors.doctorId && (
                <p className="mt-2 text-sm text-red-600">{errors.doctorId.message}</p>
              )}
            </div>
          )}

          {/* Date Selection */}
          {selectedDoctor && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Select Date
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
                {availableDates.map((date) => (
                  <label key={date.value} className="relative">
                    <input
                      {...register('appointmentDate')}
                      type="radio"
                      value={date.value}
                      className="sr-only"
                    />
                    <div className={`p-3 border-2 rounded-lg cursor-pointer transition-all text-center ${
                      selectedDate === date.value
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}>
                      <div className="text-sm font-medium text-gray-900">
                        {date.isToday ? 'Today' : date.label.split(',')[0]}
                      </div>
                      <div className="text-xs text-gray-600">
                        {date.label.split(',')[1]}
                      </div>
                    </div>
                  </label>
                ))}
              </div>
              {errors.appointmentDate && (
                <p className="mt-2 text-sm text-red-600">{errors.appointmentDate.message}</p>
              )}
            </div>
          )}

          {/* Time Slot Selection */}
          {selectedDate && availableSlots.length > 0 && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Select Time Slot
              </label>
              <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
                {availableSlots.map((slot) => (
                  <label key={slot.time} className="relative">
                    <input
                      {...register('appointmentTime')}
                      type="radio"
                      value={slot.time}
                      disabled={!slot.available}
                      className="sr-only"
                    />
                    <div className={`p-3 border-2 rounded-lg cursor-pointer transition-all text-center ${
                      !slot.available
                        ? 'border-gray-200 bg-gray-100 text-gray-400 cursor-not-allowed'
                        : watch('appointmentTime') === slot.time
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}>
                      <div className="text-sm font-medium">
                        {slot.time}
                      </div>
                    </div>
                  </label>
                ))}
              </div>
              {errors.appointmentTime && (
                <p className="mt-2 text-sm text-red-600">{errors.appointmentTime.message}</p>
              )}
            </div>
          )}

          {/* Consultation Type */}
          {selectedDate && watch('appointmentTime') && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Consultation Type
              </label>
              <div className="grid grid-cols-2 gap-4">
                <label className="relative">
                  <input
                    {...register('consultationType')}
                    type="radio"
                    value="in-person"
                    className="sr-only"
                  />
                  <div className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    watch('consultationType') === 'in-person'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-300 hover:border-gray-400'
                  }`}>
                    <div className="flex items-center space-x-3">
                      <MapPin className="w-6 h-6 text-blue-600" />
                      <div>
                        <h3 className="font-medium text-gray-900">In-Person</h3>
                        <p className="text-sm text-gray-600">Visit the hospital</p>
                      </div>
                    </div>
                  </div>
                </label>
                <label className="relative">
                  <input
                    {...register('consultationType')}
                    type="radio"
                    value="video"
                    className="sr-only"
                  />
                  <div className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    watch('consultationType') === 'video'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-300 hover:border-gray-400'
                  }`}>
                    <div className="flex items-center space-x-3">
                      <Video className="w-6 h-6 text-blue-600" />
                      <div>
                        <h3 className="font-medium text-gray-900">Video Call</h3>
                        <p className="text-sm text-gray-600">Online consultation</p>
                      </div>
                    </div>
                  </div>
                </label>
              </div>
            </div>
          )}

          {/* Booking Summary */}
          {selectedDoctor && selectedDate && watch('appointmentTime') && (
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-medium text-gray-900 mb-3">Booking Summary</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Doctor:</span>
                  <span className="font-medium">Dr. {selectedDoctor.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Department:</span>
                  <span className="font-medium">{selectedDoctor.department}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Date:</span>
                  <span className="font-medium">
                    {format(parseISO(selectedDate), 'EEEE, MMMM dd, yyyy')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Time:</span>
                  <span className="font-medium">{watch('appointmentTime')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Type:</span>
                  <span className="font-medium capitalize">{watch('consultationType')}</span>
                </div>
                <div className="flex justify-between border-t pt-2 mt-2">
                  <span className="text-gray-600">Consultation Fee:</span>
                  <span className="font-bold text-green-600">₹{selectedDoctor.consultation_fee}</span>
                </div>
              </div>
            </div>
          )}

          {/* Submit Button */}
          <div className="flex space-x-4">
            <button
              type="button"
              onClick={() => navigate('/dashboard')}
              className="flex-1 py-3 px-4 border border-gray-300 text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading || !selectedDoctor || !selectedDate || !watch('appointmentTime')}
              className="flex-1 py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isLoading ? 'Booking...' : 'Book Appointment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}